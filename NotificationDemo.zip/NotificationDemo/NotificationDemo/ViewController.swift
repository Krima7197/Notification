
import UIKit
import UserNotifications

class ViewController: UIViewController
{
    
    func initNotificationSetupCheck()
    {
        UNUserNotificationCenter.current().requestAuthorization(options: .alert) { (success, error) in
            if success
            {
                print("Success")
            }
            else
            {
                print("Error")
            }
        }
    }
    
    @IBAction func btnNotify(_ sender: Any)
    {
        let notify = UNMutableNotificationContent()
        notify.title = "Demo"
        notify.subtitle = "Demo of notification"
        notify.body = "This is local notification"
        let trig = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        let req = UNNotificationRequest(identifier: "Notify", content: notify, trigger: trig)
        UNUserNotificationCenter.current().add(req, withCompletionHandler: nil)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        initNotificationSetupCheck()
    }
}
